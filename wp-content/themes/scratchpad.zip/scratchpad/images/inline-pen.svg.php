<svg class="pen" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 293 26.1" style="enable-background:new 0 0 293 26.1;" xml:space="preserve" aria-hidden="true">
<path class="pen0" d="M289.9,3.6c0,0,3.2,1,3.2,7.5s-3.2,7.3-3.2,7.3l-1.7-2.5V6.2L289.9,3.6z"/>
<rect class="pen0" x="60.2" y="8.4" class="st0" width="178.5" height="5.4"/>
<rect class="pen0" x="276.5" y="6.2" class="st0" width="11.7" height="9.7"/>
<path class="pen1" d="M289.9,18.5H60.2V3.7h229.6c0,0,0.7,2.8,0.7,7.4C290.5,15.8,289.9,18.5,289.9,18.5z"/>
<path class="pen0" d="M68.9,21.1c0,0-33.6,1.5-68.9-7C-1.5,12.6-1.4,8.9,0,7c19.4-6.2,68.9-7,68.9-7V21.1z"/>
<path class="pen0" d="M19.5,18c0,0,31.4,7.2,45.7,7.1s30.8,0,35.6,0s12.1-1.3,12.1-2.6s-7-2.8-11.1-2.7c-4.1,0-33,0.1-33,0.1L19.5,18z"/>
<path class="pen0" d="M68.5,26.1L68.5,26.1c-0.8,0-1.4-0.6-1.4-1.4V0.7c0-0.8,0.6-1.4,1.4-1.4l0,0c0.8,0,1.4,0.6,1.4,1.4c0,0,1.2,5.3,1.2,10.4c0,7.9-1.2,13.7-1.2,13.7C69.9,25.5,69.3,26.1,68.5,26.1z"/>
</svg>
