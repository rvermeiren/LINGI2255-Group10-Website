<svg class="pencil" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="972.5px" height="55.6px" viewBox="0 0 972.5 55.6" style="enable-background:new 0 0 972.5 55.6;" xml:space="preserve" aria-hidden="true">
<g>
	<path class="pencil0" d="M10,55.6c0,0-10-8.4-10-27.5C0,6.4,10,0,10,0l871.4,0v55.6H10z"/>
	<rect x="1.7" y="19.3" class="pencil1" width="879.7" height="17.6"/>
	<polygon class="pencil2" points="1.7,17.6 10,0 881.4,0 881.4,17.6 	"/>
	<path class="pencil3" d="M972.5,27.8L881.4,0c0,0-8.4,7.5-8.4,27.8s8.4,27.8,8.4,27.8L972.5,27.8z"/>
	<path class="pencil0" d="M972.5,27.8l-33.5-10.2c0,0-3.1,2.8-3.1,10.2s3.1,10.2,3.1,10.2L972.5,27.8z"/>
	<path class="pencil3" d="M881.4,0c0,0-12.7,4.2-14,7.7c-1.3,3.5,5.7,7.1,5.7,9.9s-10,6-10,10.5s10,6,10,9.9s-5.7,6.4-5.7,10.5s14,7.1,14,7.1l11-27.5L881.4,0z"/>
</g>
</svg>
