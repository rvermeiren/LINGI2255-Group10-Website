<svg version="1.1" class="photo-corner" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="70.7px" height="70.7px" viewBox="-64 65.3 70.7 70.7" style="enable-background:new -64 65.3 70.7 70.7;" xml:space="preserve">
<polygon class="photo-corner0" points="-38,91.3 -19.3,91.3 6.7,65.3 -42.3,65.3 -64,65.3 -64,87 -64,136 -38,110 "/>
<polygon class="photo-corner1" points="-30.6,70.1 -34.4,70.1 -58.8,70.1 -59.8,70.1 -59.8,71.1 -59.8,94.6 -59.8,98.4 -59.8,124.5 -58.8,123.5 -58.8,99.3 -58.8,95.6 -58.8,71.1 -35.3,71.1 -31.6,71.1 -5.1,71.1 -4.1,70.1 "/>
<polygon class="photo-corner1" points="-42.8,86.1 -43.8,86.1 -43.8,87.1 -43.8,109.5 -42.8,108.5 -42.8,87.1 -21.1,87.1 -20.1,86.1 "/>
</svg>
