<svg class="little-pencil" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="1013.5px" height="72.3px" viewBox="0 0 1013.5 72.3" style="enable-background:new 0 0 1013.5 72.3;" xml:space="preserve" aria-hidden="true">
<path class="pencil-little0" d="M10,0C10,0,0,10.9,0,35.8c0,28.2,10,36.5,10,36.5h841.4V0H10z"/>
<path class="pencil-little1" d="M57,0c0,0-10,10.9-10,35.8c0,28.2,10,36.5,10,36.5h821.4V0L57,0z"/>
<path class="pencil-little2" d="M101,0c0,0-10,10.9-10,35.8c0,28.2,10,36.5,10,36.5h821.4V0L101,0z"/>
<rect x="92.7" y="24.3" class="pencil-little3" width="829.7" height="22.8"/>
<polygon class="pencil-little4" points="92.7,49.5 101,72.3 922.4,72.3 922.4,49.5 "/>
<path class="pencil-little5" d="M1013.5,36.1l-91.2,36.1c0,0-8.4-9.8-8.4-36.1S922.4,0,922.4,0L1013.5,36.1z"/>
<path class="pencil-little6" d="M1013.5,36.1l-33.5,13.3c0,0-3.1-3.6-3.1-13.3s3.1-13.3,3.1-13.3L1013.5,36.1z"/>
<path class="pencil-little5" d="M922.4,72.3c0,0-12.7-5.4-14-10C907,57.7,914,53,914,49.4s-10-7.8-10-13.6s10-7.8,10-12.9s-5.7-8.3-5.7-13.6s14-9.3,14-9.3l11,35.8L922.4,72.3z"/>
</svg>
