<svg version="1.1" class="grip-pencil" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="841.1px" height="54.3px" viewBox="0 0 841.1 54.3" style="enable-background:new 0 0 841.1 54.3;" xml:space="preserve">
<polygon class="grip-pencil0" points="37.5,35.8 16.8,35.8 0,30.4 16.8,25.3 37.5,25.3 "/>
<polygon class="grip-pencil1" points="202.2,51.5 40.7,44.5 40.7,16.5 202.2,9.5 "/>
<rect x="202.2" y="9.5" class="grip-pencil2" width="585.3" height="42"/>
<rect x="787.5" y="16.4" class="grip-pencil3" width="53.6" height="28.2"/>
<rect x="705.7" y="6.8" class="grip-pencil3" width="33" height="47.5"/>
<rect x="21.3" y="20.9" class="grip-pencil1" width="43.5" height="20.7"/>
<g>
	<rect x="526.5" class="grip-pencil3" width="171.5" height="13.3"/>
	<polygon class="grip-pencil4" points="698,0.4 706.5,10 706.5,21.9 698,12.5 	"/>
</g>
<polygon class="grip-pencil3" points="97,14.1 40.7,16.5 40.7,44.5 97,47 "/>
<path class="grip-pencil5" d="M550,13.3c0,0-13.2,6.2-18.5,6.2s-5-6.2-5-6.2H550z"/>
</svg>
